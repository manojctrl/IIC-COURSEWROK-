import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/**
 * The GymGUI class represents the main graphical user interface for the Gym Management System.
 * It allows users to manage both regular and premium gym members, handle memberships, track attendance,
 * apply discounts, and view member details through a Swing-based interface.
 * @author Manoj Katwal
 */
public class GymGUI {
    
    JFrame frame;
    
    JTextField idField, nameField, locationField, phoneField, emailField, referralField;
    JTextField paidField, removalField, trainerField, memberField, reguPriceField, preCharField, disAmouField;
    
    JComboBox<String> dobYearBox, dobMonthBox, dobDayBox;
    JComboBox<String> msYearBox, msMonthBox, msDayBox;
    JComboBox<String> planBox;
    
    JRadioButton maleButton, femaleButton, otherButton;
    
    ButtonGroup genderGroup;
    
    private ArrayList<GymMember> members = new ArrayList<>();
    
    JButton regularmembtn, premiumbtn, activateMembershipbtn, deactiveMembershipButtton, markAttendancebtn, 
            revertRegularMemberbtn, revertPremiumbtn, upgradeButton, discountButton;

    /**
     * Constructs the GymGUI and initializes the graphical interface.
     */
    public GymGUI() {
        createGUI();
    }
    
    /**
     * Initializes and configures all GUI components including frames, panels, labels,
     * text fields, buttons, and combo boxes. Sets up event listeners for button actions.
     */
    public void createGUI() {
        frame = new JFrame("Gym Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);
        frame.setSize(900, 900);
        Color backgroundColor = new Color(240, 240, 240);
        frame.getContentPane().setBackground(backgroundColor);

        // Header Panel
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(null);
        headerPanel.setBounds(0, 0, 900, 50);
        Color headerColor = new Color(44, 62, 80);
        headerPanel.setBackground(headerColor);
        frame.add(headerPanel);

        JLabel titleLabel = new JLabel("GYM MANAGEMENT SYSTEM");
        titleLabel.setBounds(300, 20, 700, 20);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("serif", Font.BOLD, 18));
        headerPanel.add(titleLabel);

        // Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(null);
        mainPanel.setBounds(30, 100, 820, 410);
        mainPanel.setBackground(Color.WHITE);
        mainPanel.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        frame.add(mainPanel);

        JLabel membInfo = new JLabel("Member Information");
        membInfo.setBounds(10, 10, 380, 25);
        membInfo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        mainPanel.add(membInfo);

        JLabel idLabel = new JLabel("Id:");
        idLabel.setBounds(20, 50, 150, 25);
        mainPanel.add(idLabel);

        idField = new JTextField();
        idField.setBounds(180, 50, 200, 30);
        mainPanel.add(idField);

        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(20, 90, 150, 30);
        mainPanel.add(nameLabel);

        nameField = new JTextField();
        nameField.setBounds(180, 90, 200, 30);
        mainPanel.add(nameField);

        JLabel locationLabel = new JLabel("Location:");
        locationLabel.setBounds(20, 130, 150, 30);
        mainPanel.add(locationLabel);

        locationField = new JTextField();
        locationField.setBounds(180, 130, 200, 30);
        mainPanel.add(locationField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setBounds(20, 170, 150, 30);
        mainPanel.add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(180, 170, 200, 30);
        mainPanel.add(phoneField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setBounds(20, 210, 150, 30);
        mainPanel.add(emailLabel);

        emailField = new JTextField();
        emailField.setBounds(180, 210, 200, 30);
        mainPanel.add(emailField);

        JLabel genderLabel = new JLabel("Gender");
        genderLabel.setBounds(20, 250, 150, 30);
        mainPanel.add(genderLabel);

        maleButton = new JRadioButton("Male");
        maleButton.setBounds(180, 250, 60, 30);
        maleButton.setBackground(Color.WHITE);
        mainPanel.add(maleButton);

        femaleButton = new JRadioButton("Female");
        femaleButton.setBounds(250, 250, 100, 30);
        femaleButton.setBackground(Color.WHITE);
        mainPanel.add(femaleButton);

        otherButton = new JRadioButton("Other");
        otherButton.setBounds(320, 250, 100, 30);
        otherButton.setBackground(Color.WHITE);
        mainPanel.add(otherButton);

        genderGroup = new ButtonGroup();
        genderGroup.add(maleButton);
        genderGroup.add(femaleButton);
        genderGroup.add(otherButton);

        JLabel dobLabel = new JLabel("DOB:");
        dobLabel.setBounds(20, 290, 150, 30);
        mainPanel.add(dobLabel);

        dobYearBox = new JComboBox<>(getYears());
        dobYearBox.setBounds(180, 285, 60, 25);
        mainPanel.add(dobYearBox);

        dobMonthBox = new JComboBox<>(getMonths());
        dobMonthBox.setBounds(250, 285, 60, 25);
        mainPanel.add(dobMonthBox);

        dobDayBox = new JComboBox<>(getDays());
        dobDayBox.setBounds(315, 285, 60, 25);
        mainPanel.add(dobDayBox);

        JLabel membershipLabel = new JLabel("Membership Details:");
        membershipLabel.setBounds(440, 10, 380, 25);
        membershipLabel.setFont(new Font("Segoe UI", Font.BOLD, 16));
        mainPanel.add(membershipLabel);

        JLabel membershipstart = new JLabel("Membership Start:");
        membershipstart.setBounds(440, 50, 150, 30);
        mainPanel.add(membershipstart);

        msYearBox = new JComboBox<>(getYears());
        msYearBox.setBounds(600, 50, 60, 25);
        mainPanel.add(msYearBox);

        msMonthBox = new JComboBox<>(getMonths());
        msMonthBox.setBounds(670, 50, 60, 25);
        mainPanel.add(msMonthBox);

        msDayBox = new JComboBox<>(getDays());
        msDayBox.setBounds(750, 50, 60, 25);
        mainPanel.add(msDayBox);

        JLabel referalLabel = new JLabel("Referral Source");
        referalLabel.setBounds(440, 100, 150, 30);
        mainPanel.add(referalLabel);

        referralField = new JTextField();
        referralField.setBounds(600, 100, 200, 30);
        mainPanel.add(referralField);

        JLabel paidLabel = new JLabel("Paid Amount:");
        paidLabel.setBounds(440, 140, 150, 30);
        mainPanel.add(paidLabel);

        paidField = new JTextField();
        paidField.setBounds(600, 140, 200, 30);
        mainPanel.add(paidField);

        JLabel removLabel = new JLabel("Removal Reason:");
        removLabel.setBounds(440, 180, 150, 30);
        mainPanel.add(removLabel);

        removalField = new JTextField();
        removalField.setBounds(600, 180, 200, 30);
        mainPanel.add(removalField);

        JLabel trainerLabel = new JLabel("Trainer Name:");
        trainerLabel.setBounds(440, 220, 150, 30);
        mainPanel.add(trainerLabel);

        trainerField = new JTextField();
        trainerField.setBounds(600, 220, 200, 30);
        mainPanel.add(trainerField);
        
        JLabel planLabel = new JLabel("Membership Plan:");
      planLabel.setBounds(440, 260, 150, 30);
        mainPanel.add(planLabel);

        String[] plan = {"basic", "standard", "deluxe"};
        planBox = new JComboBox<>(plan);
        planBox.setBounds(600, 260, 200, 25);
        planBox.setBackground(Color.WHITE);
        mainPanel.add(planBox);

        JLabel discountLabel = new JLabel("Discount Amount:");
        discountLabel.setBounds(440, 300, 150, 30);
        mainPanel.add(discountLabel);   

        disAmouField = new JTextField();
        disAmouField.setBounds(600, 300, 200, 30);
        disAmouField.setEditable(false);
        disAmouField.setEnabled(false);
        mainPanel.add(disAmouField);

        JLabel regularPlanPrice = new JLabel("Regular Plan Price");
        regularPlanPrice.setBounds(440, 340, 150, 30);
        mainPanel.add(regularPlanPrice);

        reguPriceField = new JTextField();
        reguPriceField.setBounds(600, 340, 200, 30);
        reguPriceField.setText("6500");
        reguPriceField.setEditable(false);
        reguPriceField.setEnabled(false);
        mainPanel.add(reguPriceField);

        JLabel premiumPlanPrice = new JLabel("Premium Plan Price");
        premiumPlanPrice.setBounds(440, 380, 150, 30);
        mainPanel.add(premiumPlanPrice);

        preCharField = new JTextField();
        preCharField.setBounds(600, 380, 200, 30);
        preCharField.setText("50000");
        preCharField.setEditable(false);
        preCharField.setEnabled(false);
        mainPanel.add(preCharField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(null);
        buttonPanel.setBounds(30, 500, 820, 400);
        frame.add(buttonPanel);

        regularmembtn = new JButton("Add Regular Member");
        regularmembtn.setBounds(30, 30, 200, 30);
        regularmembtn.setBackground(headerColor);
        regularmembtn.setForeground(Color.WHITE);
        regularmembtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(regularmembtn);

        premiumbtn = new JButton("Add Premium Member");
        premiumbtn.setBounds(300, 30, 200, 30);
        premiumbtn.setBackground(headerColor);
        premiumbtn.setForeground(Color.WHITE);
        premiumbtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(premiumbtn);

        regularmembtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addRegularMember();
            }
        });
        
        premiumbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPremiumMember();
            }
        });

        activateMembershipbtn = new JButton("Activate Membership");
        activateMembershipbtn.setBounds(600, 30, 200, 30);
        activateMembershipbtn.setBackground(headerColor);
        activateMembershipbtn.setForeground(Color.WHITE);
        activateMembershipbtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(activateMembershipbtn);

        activateMembershipbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addactivateMembership();
            }
        });

        deactiveMembershipButtton = new JButton("Deactivate Membership");
        deactiveMembershipButtton.setBounds(30, 90, 200, 30);
        deactiveMembershipButtton.setBackground(headerColor);
        deactiveMembershipButtton.setForeground(Color.WHITE);
        deactiveMembershipButtton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(deactiveMembershipButtton);

        deactiveMembershipButtton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adddeactiveMembershipButtton();
            }
        });

        markAttendancebtn = new JButton("Mark Attendance");
        markAttendancebtn.setBounds(300, 90, 200, 30);
        markAttendancebtn.setBackground(headerColor);
        markAttendancebtn.setForeground(Color.WHITE);
        markAttendancebtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(markAttendancebtn);

        markAttendancebtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addmarkAttendancebtn();
            }
        });

        revertRegularMemberbtn = new JButton("Revert Regular Member");
        revertRegularMemberbtn.setBounds(600, 90, 200, 30);
        revertRegularMemberbtn.setBackground(headerColor);
        revertRegularMemberbtn.setForeground(Color.WHITE);
        revertRegularMemberbtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(revertRegularMemberbtn);

        revertRegularMemberbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addrevertRegularMemberbtn();
            }
        });

        revertPremiumbtn = new JButton("Revert Premium Member");
        revertPremiumbtn.setBounds(30, 150, 200, 30);          
        revertPremiumbtn.setBackground(headerColor);
        revertPremiumbtn.setForeground(Color.WHITE);        
        revertPremiumbtn.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(revertPremiumbtn);

        revertPremiumbtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addrevertPremiumMemberbtn();
            }
        });

        JButton displayMembersButton = new JButton("Display Members");
        displayMembersButton.setBounds(300, 150, 200, 30);
        displayMembersButton.setBackground(headerColor);
        displayMembersButton.setForeground(Color.WHITE);
        displayMembersButton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(displayMembersButton);

        displayMembersButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayMembers();
            }
        });

        JButton clearFieldsButton = new JButton("Clear Fields");
        clearFieldsButton.setBounds(600, 150, 200, 30);    
        clearFieldsButton.setBackground(headerColor);
        clearFieldsButton.setForeground(Color.WHITE);
        clearFieldsButton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(clearFieldsButton);

        clearFieldsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        discountButton = new JButton("Calculate Discount");
        discountButton.setBounds(30, 210, 200, 30);
        discountButton.setBackground(headerColor);
        discountButton.setForeground(Color.WHITE);
        discountButton.setFont(new Font("Poppins", Font.PLAIN, 14)); 
        buttonPanel.add(discountButton);

        discountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateDiscount();
            }
        });

        upgradeButton = new JButton("Upgrade Plan");
        upgradeButton.setBounds(300, 210, 200, 30);
        upgradeButton.setBackground(headerColor);
        upgradeButton.setForeground(Color.WHITE);
        upgradeButton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(upgradeButton);

        upgradeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addUpgradePlan();
            }
        });

        JButton payDueAmountButton = new JButton("Pay Due Amount");
        payDueAmountButton.setBounds(600, 210, 200, 30);
        payDueAmountButton.setBackground(headerColor);
        payDueAmountButton.setForeground(Color.WHITE);
        payDueAmountButton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(payDueAmountButton);

        payDueAmountButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addPayDueAmount();
            }
        });

        JButton savetoFileButton = new JButton("Save to File");
        savetoFileButton.setBounds(30, 270, 200, 30);
        savetoFileButton.setBackground(headerColor);
        savetoFileButton.setForeground(Color.WHITE);
        savetoFileButton.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(savetoFileButton);

        savetoFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                saveToFile();
            }
        });

        JButton readFromFile = new JButton("Read from File");
        readFromFile.setBounds(300, 270, 200, 30);
        readFromFile.setBackground(headerColor);
        readFromFile.setForeground(Color.WHITE);
        readFromFile.setFont(new Font("Poppins", Font.PLAIN, 14));
        buttonPanel.add(readFromFile);

        readFromFile.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                readFromFile();
            }
        });

        frame.setVisible(true);
    }

    /**
     * Generates an array of years for date selection (1975-2025).
     * @return String array containing year values
     */
    private String[] getYears() {
        String[] years = new String[50];
        for (int i = 0; i < 50; i++) {
            years[i] = String.valueOf(2025 - i);
        }
        return years;
    }
    
    /**
     * Generates an array of months for date selection (1-12).
     * @return String array containing month values
     */
    private String[] getMonths() {
        String[] months = new String[12];
        for (int i = 0; i < 12; i++) {
            months[i] = String.valueOf(i + 1);
        }
        return months;
    }

    /**
     * Generates an array of days for date selection (1-31).
     * @return String array containing day values
     */
    public String[] getDays() {
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) {
            days[i] = String.valueOf(i + 1);
        }
        return days;
    }

    /**
     * Checks if a member ID already exists.
     * @param id The ID to check
     * @return The GymMember if found, null otherwise
     */
    private GymMember isValidId(int id) {
        for (GymMember member : members) {
            if (member.getId() == id) {
                return member;
            }
        }
        return null; 
    }

    /**
     * Adds a new regular member to the system after validating input fields.
     * Collects personal information, membership details, and referral source.
     * Displays error messages for invalid inputs or duplicate IDs.
     */
    public void addRegularMember() {
        try {
            int id = Integer.parseInt(idField.getText());
            if (isValidId(id) != null) {
                JOptionPane.showMessageDialog(frame, "The id already exists, please enter another id.", "Warning", JOptionPane.WARNING_MESSAGE);
                return;
            }

            String name = nameField.getText();
            String location = locationField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String referral = referralField.getText();
            
            String gender = "";
            if (maleButton.isSelected()) {
                gender = "male";
            } else if (femaleButton.isSelected()) {
                gender = "female";
            } else if (otherButton.isSelected()) {
                gender = "other";
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a gender!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (dobYearBox.getSelectedIndex() == -1 || dobMonthBox.getSelectedIndex() == -1 || dobDayBox.getSelectedIndex() == -1 ||
                msYearBox.getSelectedIndex() == -1 || msMonthBox.getSelectedIndex() == -1 || msDayBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(frame, "Please select valid dates for DOB and Membership Start!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String DOB = dobYearBox.getSelectedItem() + "-" + dobMonthBox.getSelectedItem() + "-" + dobDayBox.getSelectedItem();
            String membershipStartDate = msYearBox.getSelectedItem() + "-" + msMonthBox.getSelectedItem() + "-" + msDayBox.getSelectedItem();

            if (name.isEmpty() || location.isEmpty() || phone.isEmpty() || email.isEmpty() || referral.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all the required fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!phone.matches("\\d{10}")) {
                JOptionPane.showMessageDialog(frame, "Phone number must be exactly 10 digits (e.g., 1234567890)!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            if (!email.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid email address (e.g., example@domain.com)!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            RegularMember member = new RegularMember(id, name, location, phone, email, gender, DOB, membershipStartDate, referral);
            members.add(member);
            JOptionPane.showMessageDialog(frame, "Successfully added to Regular Member!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid ID number!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Adds a new premium member to the system with personal trainer information.
     * Validates required fields and checks for duplicate IDs.
     * Shows error messages for incomplete data or invalid inputs.
     */
    public void addPremiumMember() {
        try {
            int id = Integer.parseInt(idField.getText());
            if (isValidId(id) != null) {
                JOptionPane.showMessageDialog(frame, "Duplicate ID exists. Please enter a unique ID.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String name = nameField.getText();
            String location = locationField.getText();
            String phone = phoneField.getText();
            String email = emailField.getText();
            String trainer = trainerField.getText();

            String gender = "";
            if (maleButton.isSelected()) {
                gender = "male";
            } else if (femaleButton.isSelected()) {
                gender = "female";
            } else if (otherButton.isSelected()) {
                gender = "other";
            } else {
                JOptionPane.showMessageDialog(frame, "Please select a gender!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (dobYearBox.getSelectedIndex() == -1 || dobMonthBox.getSelectedIndex() == -1 || dobDayBox.getSelectedIndex() == -1 ||
                msYearBox.getSelectedIndex() == -1 || msMonthBox.getSelectedIndex() == -1 || msDayBox.getSelectedIndex() == -1) {
                JOptionPane.showMessageDialog(frame, "Please select valid dates for DOB and Membership Start!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String DOB = dobYearBox.getSelectedItem() + "-" + dobMonthBox.getSelectedItem() + "-" + dobDayBox.getSelectedItem();
            String membershipStartDate = msYearBox.getSelectedItem() + "-" + msMonthBox.getSelectedItem() + "-" + msDayBox.getSelectedItem();

            if (name.isEmpty() || location.isEmpty() || phone.isEmpty() || email.isEmpty() || trainer.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please fill all the required fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!phone.matches("\\d{10}")) {
                JOptionPane.showMessageDialog(frame, "Phone number must be exactly 10 digits (e.g., 1234567890)!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
    
            if (!email.matches("^[\\w._%+-]+@[\\w.-]+\\.[a-zA-Z]{2,}$")) {
                JOptionPane.showMessageDialog(frame, "Please enter a valid email address (e.g., example@domain.com)!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            PremiumMember member = new PremiumMember(id, name, location, phone, email, gender, DOB, membershipStartDate, trainer);
            members.add(member);
            JOptionPane.showMessageDialog(frame, "Successfully added to Premium Members!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
            
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Please enter a valid ID!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
     * Activates a member's membership using their ID.
     * Shows error if member not found or invalid ID format is entered.
     */
    public void addactivateMembership() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            member.activateMembership();
            JOptionPane.showMessageDialog(frame, "Membership activated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Deactivates a member's membership using their ID.
     * Displays error messages for invalid ID or non-existent members.
     */
    public void adddeactiveMembershipButtton() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            member.deactivateMembership();
            JOptionPane.showMessageDialog(frame, "Membership deactivated successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Marks attendance for a member if their membership is active.
     * Requires valid member ID and active membership status.
     */
    public void addmarkAttendancebtn() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!member.getActiveStatus()) {
                JOptionPane.showMessageDialog(frame, "Member is not active!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            member.markAttendance();
            JOptionPane.showMessageDialog(frame, "Attendance marked successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Reverts a regular member's status with a removal reason.
     * Checks member type and validates removal reason input.
     */
    public void addrevertRegularMemberbtn() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!(member instanceof RegularMember)) {
                JOptionPane.showMessageDialog(frame, "This member is not a regular member!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String reason = removalField.getText();
            if (reason.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please provide a removal reason!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            RegularMember regularMember = (RegularMember) member;
            regularMember.revertRegularMember(reason);
            JOptionPane.showMessageDialog(frame, "Regular member reverted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Reverts a premium member's status with a removal reason.
     * Checks member type and validates removal reason input.
     */
    public void addrevertPremiumMemberbtn() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!(member instanceof PremiumMember)) {
                JOptionPane.showMessageDialog(frame, "This member is not a premium member!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String reason = removalField.getText();
            if (reason.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Please provide a removal reason!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            PremiumMember premiumMember = (PremiumMember) member;
            premiumMember.revertPremiumMember();
            JOptionPane.showMessageDialog(frame, "Premium member reverted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException efc) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Displays all members in a scrollable text area with detailed information.
     * Shows different details for regular and premium members including:
     * - Membership status
     * - Attendance records
     * - Payment information
     * - Loyalty points
     */
    public void displayMembers() {
        JFrame displayFrame = new JFrame("Member List");
        displayFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        displayFrame.setSize(600, 600);
        displayFrame.setLayout(null);

        JTextArea displayArea = new JTextArea();
        displayArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(displayArea);
        scrollPane.setBounds(10, 10, 560, 540);
        displayFrame.add(scrollPane);

        if (members.isEmpty()) {
            displayArea.setText("No members found!");
        } else {
            StringBuilder displayText = new StringBuilder();
            for (GymMember member : members) {
                if (member instanceof RegularMember) {
                    displayText.append("--- REGULAR MEMBER ---\n");
                } else if (member instanceof PremiumMember) {
                    displayText.append("--- PREMIUM MEMBER ---\n");
                }
                displayText.append("ID: ").append(member.getId()).append("\n");
                displayText.append("Name: ").append(member.getName()).append("\n");
                displayText.append("Location: ").append(member.getLocation()).append("\n");
                displayText.append("Phone: ").append(member.getPhone()).append("\n");
                displayText.append("Email: ").append(member.getEmail()).append("\n");
                displayText.append("Gender: ").append(member.getGender()).append("\n");
                displayText.append("DOB: ").append(member.getDOB()).append("\n");
                displayText.append("Start Date: ").append(member.getMembershipStartDate()).append("\n");
                displayText.append("Attendance: ").append(member.getAttendance()).append("\n");
                displayText.append("Loyalty Points: ").append(member.getLoyaltyPoints()).append("\n");
                displayText.append("Active Status: ").append(member.getActiveStatus()).append("\n");

                if (member instanceof RegularMember) {
                    RegularMember regMember = (RegularMember) member;
                    displayText.append("Plan: ").append(regMember.getPlan()).append("\n");
                    displayText.append("Price: ").append(regMember.getPrice()).append("\n");
                    String removalReason = regMember.getRemovalReason();
                    if (removalReason != null && !removalReason.isEmpty()) {
                        displayText.append("Removal Reason: ").append(removalReason).append("\n");
                    }
                } else if (member instanceof PremiumMember) {
                    PremiumMember premMember = (PremiumMember) member;
                    displayText.append("Personal Trainer: ").append(premMember.getPersonalTrainer()).append("\n");
                    displayText.append("Paid Amount: ").append(premMember.getPaidAmount()).append("\n");
                    displayText.append("Payment Status: ").append(premMember.getIsFullPayment() ? "Complete" : "Incomplete").append("\n");
                    double remainingAmount = premMember.getPremiumCharge() - premMember.getPaidAmount();
                    displayText.append("Remaining Amount: ").append(remainingAmount).append("\n");
                    if (premMember.getIsFullPayment()) {
                        displayText.append("Discount Amount: ").append(premMember.getDiscountAmount()).append("\n");
                    }
                }
                displayText.append("\n---------------------------\n\n");
            }
            displayArea.setText(displayText.toString());
        }

        displayFrame.setVisible(true);
    }

    /**
     * Clears all input fields in the GUI.
     */
    private void clearFields() {
        nameField.setText("");
        locationField.setText("");
        phoneField.setText("");
        emailField.setText("");
        idField.setText("");
        dobYearBox.setSelectedIndex(-1);
        dobMonthBox.setSelectedIndex(-1);
        dobDayBox.setSelectedIndex(-1);
        msYearBox.setSelectedIndex(-1);
        msMonthBox.setSelectedIndex(-1);
        msDayBox.setSelectedIndex(-1);
        disAmouField.setText("");
        referralField.setText("");
        paidField.setText("");
        removalField.setText("");
        trainerField.setText("");
        genderGroup.clearSelection();
        planBox.setSelectedIndex(-1);
    }

    /**
     * Calculates and displays discount amount for premium members who made full payment.
     * Shows error for non-premium members or incomplete payments.
     */
    public void calculateDiscount() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!(member instanceof PremiumMember)) {
                JOptionPane.showMessageDialog(frame, "Only premium members can calculate discount!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            PremiumMember premiumMember = (PremiumMember) member;
            try {
                double premiumCharge = Double.parseDouble(preCharField.getText());
                premiumMember.payDueAmount(premiumCharge);
                premiumMember.calculateDiscount();
                
                if (premiumMember.getIsFullPayment()) {
                    disAmouField.setText(String.valueOf(premiumMember.getDiscountAmount()));
                } else {
                    disAmouField.setText("0");
                }
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Invalid premium charge amount!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Upgrades a regular member's plan based on attendance and current plan.
     * Validates attendance requirements and active membership status.
     * Updates plan price display after successful upgrade.
     */
    public void addUpgradePlan() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!(member instanceof RegularMember)) {
                JOptionPane.showMessageDialog(frame, "Only regular members can upgrade plans!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (!member.getActiveStatus()) {
                JOptionPane.showMessageDialog(frame, "Membership is not active!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            RegularMember regularMember = (RegularMember) member;
            
            if (regularMember.getAttendance() < regularMember.getAttendanceLimit()) {
                JOptionPane.showMessageDialog(frame, 
                    "Member needs " + (regularMember.getAttendanceLimit() - regularMember.getAttendance()) + 
                    " more visits to be eligible for upgrade", 
                    "Not Eligible", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            String newPlan = (String) planBox.getSelectedItem();
            
            if (newPlan == null || newPlan.equalsIgnoreCase(regularMember.getPlan())) {
                JOptionPane.showMessageDialog(frame, 
                    "Member is already on " + regularMember.getPlan() + " plan!", 
                    "Same Plan", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
            
            String result = regularMember.upgradePlan(newPlan);
            JOptionPane.showMessageDialog(frame, result, "Upgrade Status", JOptionPane.INFORMATION_MESSAGE);
            
            reguPriceField.setText(String.valueOf(regularMember.getPrice()));
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Processes payment of due amount for premium members.
     */
    public void addPayDueAmount() {
        try {
            int id = Integer.parseInt(idField.getText());
            GymMember member = isValidId(id);
            if (member == null) {
                JOptionPane.showMessageDialog(frame, "Member not found!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!(member instanceof PremiumMember)) {
                JOptionPane.showMessageDialog(frame, "Only premium members can pay due amount!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            PremiumMember premiumMember = (PremiumMember) member;
            try {
                double premiumCharge = Double.parseDouble(preCharField.getText());
                premiumMember.payDueAmount(premiumCharge);
                JOptionPane.showMessageDialog(frame, "Successfully paid the due amount!", "Success", JOptionPane.INFORMATION_MESSAGE);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(frame, "Invalid premium charge amount!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        } catch (NumberFormatException efx) {
            JOptionPane.showMessageDialog(frame, "Invalid ID format! Please enter a number.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Saves member details to a text file.
     */
    private void saveToFile() {
        try (FileWriter writer = new FileWriter("MembersDetails.txt")) {
            writer.write("Gym Member Details\n");
            writer.write(String.format("%-5s %-15s %-15s %-15s %-25s %-20s %-10s %-10s %-10s %-10s %-15s %-10s %-15s %-15s %-15s\n", 
                "ID", "Name", "Location", "Phone", "Email", "Membership Start Date", "Plan", 
                "Price", "Attendance", "Loyalty Points", "Active Status", "Full Payment", 
                "Discount Amount", "Paid Amount", "Net Amount Paid"));

            for (GymMember member : members) {
                if (member instanceof RegularMember) {
                    RegularMember regular = (RegularMember) member;
                    writer.write(String.format("%-5d %-15s %-15s %-15s %-25s %-20s %-10s %-10.2f %-10d %-10.2f %-15b %-10s %-15s %-15s %-15s\n", 
                        regular.getId(), regular.getName(), regular.getLocation(), regular.getPhone(), 
                        regular.getEmail(), regular.getMembershipStartDate(), regular.getPlan(), 
                        regular.getPrice(), regular.getAttendance(), regular.getLoyaltyPoints(), 
                        regular.getActiveStatus(), "N/A", "N/A", "N/A", "N/A"));
                } else if (member instanceof PremiumMember) {
                    PremiumMember premium = (PremiumMember) member;
                    writer.write(String.format("%-5d %-15s %-15s %-15s %-25s %-20s %-10s %-10s %-10d %-10.2f %-15b %-10b %-15.2f %-15.2f %-15.2f\n", 
                        premium.getId(), premium.getName(), premium.getLocation(), premium.getPhone(), 
                        premium.getEmail(), premium.getMembershipStartDate(), "Premium", 
                        "N/A", premium.getAttendance(), premium.getLoyaltyPoints(), 
                        premium.getActiveStatus(), premium.getIsFullPayment(), premium.getDiscountAmount(), 
                        premium.getPaidAmount(), (premium.getPremiumCharge() - premium.getPaidAmount())));
                }
            }
            JOptionPane.showMessageDialog(frame, "Members saved to file successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Reads member details from a text file and displays them.
     */
    public void readFromFile() {
        JTextArea textArea = new JTextArea(20, 80);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        try (Scanner scanner = new Scanner(new File("MembersDetails.txt"))) {
            while (scanner.hasNextLine()) {
                textArea.append(scanner.nextLine() + "\n");
            }
            JOptionPane.showMessageDialog(frame, scrollPane, "Member Details", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error reading file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new GymGUI();
    }
}