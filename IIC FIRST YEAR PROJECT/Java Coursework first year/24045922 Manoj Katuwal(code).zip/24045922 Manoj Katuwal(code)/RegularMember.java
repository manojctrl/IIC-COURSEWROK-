/**
 * Class representing a regular gym member.
 * A regular member has access to a plan with a fixed price and may upgrade after reaching a certain attendance threshold.
 * This class extends the abstract class GymMember.
 * 
 * @author Manoj Katwal
 */
public class RegularMember extends GymMember {
    private final int attendanceLimit = 30;
    private boolean isEligibleForUpgrade;
    private String removalReason;
    private String referralSource;
    private String plan;
    private double price;

    /**
     * Constructs a RegularMember with the provided personal and referral information.
     *
     * @param id Unique member ID
     * @param name Member's full name
     * @param location Member's location
     * @param phone Member's phone number
     * @param email Member's email address
     * @param gender Member's gender
     * @param DOB Member's date of birth
     * @param membershipStartDate Date when the membership started
     * @param referralSource Source through which the member was referred
     */
    public RegularMember(int id, String name, String location, String phone, String email,
                         String gender, String DOB, String membershipStartDate, String referralSource) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.isEligibleForUpgrade = false;
        this.removalReason = "";
        this.referralSource = referralSource;
        this.plan = "basic";
        this.price = 6500;
    }

    // Getter methods
    public int getAttendanceLimit() { return attendanceLimit; }
    public boolean getIsEligibleForUpgrade() { return isEligibleForUpgrade; }
    public String getRemovalReason() { return removalReason; }
    public String getReferralSource() { return referralSource; }
    public String getPlan() { return plan; }
    public double getPrice() { return price; }

    /**
     * Increases the attendance and loyalty points by 1 and 5 respectively.
     * Marks the member as eligible for upgrade if attendance reaches the limit.
     */
    @Override
    public void markAttendance() {
        this.attendance++;
        this.loyaltyPoints += 5;
        if (this.attendance >= attendanceLimit) {
            this.isEligibleForUpgrade = true;
        }
    }

    /**
     * Returns the price of the specified membership plan.
     *
     * @param plan The membership plan name (basic, standard, deluxe)
     * @return Price of the plan or -1 if the plan is invalid
     */
    public double getPlanPrice(String plan) {
        switch(plan.toLowerCase()) {
            case "basic": return 6500;
            case "standard": return 12500;
            case "deluxe": return 18500;
            default: return -1;
        }
    }

    /**
     * Attempts to upgrade the member's current plan.
     *
     * @param newPlan The new plan to upgrade to
     * @return A message indicating the result of the upgrade attempt
     */
    public String upgradePlan(String newPlan) {
        if (!isEligibleForUpgrade) {
            return "Not eligible for upgrade. Need more attendance.";
        }
        
        if (newPlan.toLowerCase().equals(this.plan)) {
            return "Already subscribed to this plan.";
        }

        double newPrice = getPlanPrice(newPlan);
        if (newPrice == -1) {
            return "Invalid plan selected.";
        }

        this.plan = newPlan.toLowerCase();
        this.price = newPrice;
        return "Plan upgraded successfully to " + newPlan;
    }

    /**
     * Reverts the member to the default basic plan and resets their status.
     *
     * @param removalReason The reason for reverting the membership
     */
    public void revertRegularMember(String removalReason) {
        super.resetMember();
        this.isEligibleForUpgrade = false;
        this.plan = "basic";
        this.price = 6500;
        this.removalReason = removalReason;
    }

    /**
     * Displays the member’s personal, membership, and plan details.
     */
    @Override
    public void display() {
        super.display();
        System.out.println("Plan: " + plan);
        System.out.println("Price: " + price);
        if (!removalReason.isEmpty()) {
            System.out.println("Removal Reason: " + removalReason);
        }
    }
}