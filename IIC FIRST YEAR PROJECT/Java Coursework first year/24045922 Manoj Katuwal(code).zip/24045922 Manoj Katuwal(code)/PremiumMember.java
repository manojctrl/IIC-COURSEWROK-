/**
 * Class representing a premium gym member.
 * Premium members pay a fixed charge and may receive a discount for full payment.
 * This class extends the abstract class GymMember.
 * 
 * @author Manoj Katwal
 */
public class PremiumMember extends GymMember {
    private final double premiumCharge = 50000;
    private String personalTrainer;
    private boolean isFullPayment;
    private double paidAmount;
    private double discountAmount;

    /**
     * Constructs a PremiumMember with the provided details and assigned personal trainer.
     *
     * @param id Unique member ID
     * @param name Member's full name
     * @param location Member's address or location
     * @param phone Member's phone number
     * @param email Member's email address
     * @param gender Member's gender
     * @param DOB Member's date of birth
     * @param membershipStartDate Date when the membership began
     * @param personalTrainer Name of the personal trainer assigned
     */
    public PremiumMember(int id, String name, String location, String phone, String email,
                         String gender, String DOB, String membershipStartDate, String personalTrainer) {
        super(id, name, location, phone, email, gender, DOB, membershipStartDate);
        this.personalTrainer = personalTrainer;
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

    // Getter methods
    public double getPremiumCharge() { return premiumCharge; }
    public String getPersonalTrainer() { return personalTrainer; }
    public boolean getIsFullPayment() { return isFullPayment; }
    public double getPaidAmount() { return paidAmount; }
    public double getDiscountAmount() { return discountAmount; }

    /**
     * Marks attendance for the premium member and adds loyalty points.
     */
    @Override
    public void markAttendance() {
        this.attendance++;
        this.loyaltyPoints += 5;
    }

    /**
     * Processes a payment towards the premium charge.
     *
     * @param amount The amount being paid
     * @return A message indicating success or error of the payment process
     */
    public String payDueAmount(double amount) {
        if (this.isFullPayment) {
            return "Payment is already complete.";
        }

        if (this.paidAmount + amount > premiumCharge) {
            return "Payment amount exceeds the premium charge.";
        }

        this.paidAmount += amount;
        if (this.paidAmount == premiumCharge) {
            this.isFullPayment = true;
        }

        double remainingAmount = premiumCharge - this.paidAmount;
        return "Payment successful. Remaining amount: " + remainingAmount;
    }

    /**
     * Calculates a 10% discount on the premium charge if the full payment is completed.
     */
    public void calculateDiscount() {
        if (isFullPayment) {
            this.discountAmount = premiumCharge * 0.10;
            System.out.println("Discount calculated: " + discountAmount);
        } else {
            System.out.println("No discount available. Complete payment first.");
        }
    }

    /**
     * Resets the member to default values for re-registration or downgrade purposes.
     */
    public void revertPremiumMember() {
        super.resetMember();
        this.personalTrainer = "";
        this.isFullPayment = false;
        this.paidAmount = 0;
        this.discountAmount = 0;
    }

    /**
     * Displays all member details including premium payment status and discount.
     */
    @Override
    public void display() {
        super.display();
        System.out.println("Personal Trainer: " + personalTrainer);
        System.out.println("Paid Amount: " + paidAmount);
        System.out.println("Payment Status: " + (isFullPayment ? "Complete" : "Incomplete"));
        double remainingAmount = premiumCharge - paidAmount;
        System.out.println("Remaining Amount: " + remainingAmount);
        if (isFullPayment) {
            System.out.println("Discount Amount: " + discountAmount);
        }
    }
}
